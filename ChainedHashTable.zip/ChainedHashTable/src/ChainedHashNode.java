class ChainedHashNode
{
   Object element;
   int key;
   ChainedHashNode link;
   
   	 public ChainedHashNode(int k, Object e)
   	 {
   		 this.element = e;
   		 this.key = k;
   		 this.link = null;
   	 }
   	
     public Object getValue() 
     {
       	   return this.element;
     }

     public void setValue(Object value) 
     {
	   	   this.element = value;
     }

	 public int getKey() {
	       return key;
	 }

	 public ChainedHashNode getNext() {
	       return this.link;
	 }

	 public void setNext(ChainedHashNode next) {
		   this.link = next;
	 }
  
}