import java.util.Random;

public class MainFrame 
{
	public static void main(String[] args) 
	{
		PriorityQueue heap = new PriorityQueue();						//creates a heap array of size 20
		
		for(int i = 0; i < 20; i++) 									//fills an array-list with 20 sorted random numbers
		{																//prints theHeap
			
			Data random = new Data ( randomizeNumber() );
			System.out.println("<=======================" +" HeapSize: " +i + "==========================> ");
			heap.insert(i, random);
			heap.print(0, 1);		
		}
		
		System.out.println("20 items have been inserted into the heap. ");
		
		for(int i = 1; i < 20; i++)										//Removes the root node, re-heapify & then print
		{	
			if(heap.theHeap.size() > 1)
			{
				heap.remove();
				System.out.println( "<======================= Removal: "+ (i+1)  + "==========================> ");
				if(!heap.theHeap.isEmpty() )
				{
					heap.print(0, 1);
				}else {
					System.out.println(" All items have been removed from the heap. ");
				}
				
			}
		}
		
		if(heap.theHeap.size() == 1 )
		{
			System.out.println("Removing: "+heap.theHeap.get(0));
			heap.theHeap.remove(0);
			System.out.print("The heap is empty."); 
		}

	}
	
	public static int randomizeNumber()
	{
		Random rand = new Random();
		
		int value = rand.nextInt(1000);
		return value;
	}

}
