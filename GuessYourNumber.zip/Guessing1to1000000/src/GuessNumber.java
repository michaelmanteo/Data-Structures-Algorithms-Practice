import java.util.*;
public class GuessNumber 
{
	private int low;
	private int high;
	private int mid;
	private int q; 
	Scanner s = new Scanner(System.in);
	
	public GuessNumber ()
	{
		low = 0;
		high = 1000000;
		
	}
	
	public void reduceNumber( int midpoint )
	{
		mid = midpoint;
		
		if(low == mid || high == mid )
		{
			System.out.println("Your number is: " +low);
		}else{
			System.out.println("Is it greater than or equal to: "+ midpoint +"? 'Yes: 1' or 'No: 0' ");
			q = s.nextInt();
			if(q == 1)
			{
				low = midpoint;
				mid = ( low + high ) / 2;
				reduceNumber(mid);
			}else if(q == 0)
			{
				high = midpoint;
				mid = ( low + high) /2;
				reduceNumber(mid);
			}else if(q != 0 || q != 1)
			{
				System.out.println("You have entered an invalid answer.");
			}
		}
	}
	
	public static void main(String[] args)
	{
		int mid = (1000000 + 1) / 2;
		
		System.out.println("This program can guess a random number between 1 and 1000000 ");
		GuessNumber g = new GuessNumber();
		g.reduceNumber(mid);
	}
}
