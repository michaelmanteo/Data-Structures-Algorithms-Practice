public class Data
{
		int key;
		
		public Data (int k)
		{
			this.key = k;
		}
		
		public String toString()
		{
			return Integer.toString(key);
		}
}