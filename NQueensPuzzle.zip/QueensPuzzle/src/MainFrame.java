/* Michael N. Manteo
 * SUNY New Paltz
 * Computer Science III: Data Structures & Algorithms
 * Graded Homework Program #2 - N-Queens Puzzle
 * */


import java.util.Scanner;

public class MainFrame 
{	
	public static void main(String[] args )
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to the N-Queens Puzzle Solution Generator.");
		System.out.print("Enter a value for N: ");
		Queen q = new Queen( sc.nextInt());
		sc.close();
		q.putQueen();		
	}
	
}
