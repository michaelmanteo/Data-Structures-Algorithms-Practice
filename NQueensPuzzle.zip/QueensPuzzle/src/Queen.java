/* Michael N. Manteo
 * SUNY New Paltz
 * Computer Science III: Data Structures & Algorithms
 * Graded Homework Program #2 - N-Queens Puzzle
 * */

import java.util.Stack;

public class Queen 
{
	private int n = 0; 		//the number of Queens
	int colum = 0; 	 		//represent the indices of the stack (row)
	int stackTop = 0; 		//to hold the top variable from the stack
	int solutions = 0;		//to record the number of solutions found
	
	//row is stack number, value is [colum]
	Stack <Integer> s = new Stack<Integer>();
	
	/* Queen class constructor: sets the input = to N
	 * 							Checks that N is a valid input*/
	public Queen(int q) 
	{
		n = q;
		if( n <= 3)
		{
			System.out.println("Chessboard (N) too small! Cannot solve!");
		}
	}
	
	
	/*Precondition: Check the row number passed
	 *Postconition: return if queen is safe or not (T/F) */
	private boolean isQueenSafe(int tempColum)
	{
		for (int r = 0; r < s.size(); r++) 
		{
            //check if row = colum
			if ( s.get(r) == tempColum )
            {
                return false;
            }
            
            if ( Math.abs(tempColum - s.get(r)) == s.size() - r)
            {
                return false;
            }
        }
        return true;
	}
	
	
	/* Precondition: a solved queens puzzle stack (row) full of column numbers
	 * Postcondition: printed Queen's puzzle
	 * */
	private void printQueen( Stack<Integer> s)
	{
		System.out.println("Solution#: " +solutions );
		
		for (int x = 0; x < s.size(); x++)
		{
			for (int y = 0; y <= s.size(); y++)
			{
	        	if (s.get(x) == y + 1)
	        	{
					System.out.print("Q ");
	        	}else{
	        		System.out.print("* ");
	        	}
			}
    		System.out.println();
		}
	}
	
	/*Precondition: uses the input N to solve the Queen's puzzle. Two queens may not intercept by 
	 * row, column, or diagonal. Utilizes back-tracking algorithm 
	 *Postcondition: the stack will be filled (by row) with appropriate column numbers */
	public boolean putQueen( )
	{
		
		while(colum <= n)
		{
			boolean queenPlaced = false;
			for (int row = stackTop + 1; row <= n ; row++) 
			{
				if ( isQueenSafe(row) ) 
				{         
					queenPlaced = true;
					s.push(row);
					colum++;
				
					if(colum == n)	//solution found
					{
						solutions++;
						//print solution number and puzzle board
						printQueen(s);
					}
					break;
				}
			}
			
			//BACKTRACKING
			if ( queenPlaced == false ) 
			{
		        if ( s.isEmpty() )
		        {
		           return false;
		        }
		       
		        stackTop = s.pop();			
		        colum--;
		    
			} else {
		           stackTop = 0;
		    }
		}
		return false;
	}
}
