import java.util.ArrayList;

public class PriorityQueue
	{
		ArrayList<Data> theHeap = new ArrayList<Data>();
		
		public PriorityQueue() {}
		
		public void insert(int index, Data newData)
		{
			System.out.println("insert() called. ");
			theHeap.add(index, newData);
			
			if (index != 0)									//do not need to heap the 0th element
			{
				Data root = new Data(0);
				root = theHeap.get(index);
				int parentIndex = ( index - 1 ) /2;
				Data parent = theHeap.get(parentIndex);
				
				//push up algorithm
				while(theHeap.get(index).key > theHeap.get(parentIndex).key )					//repeat while the root is greater than its parent
				{	
					theHeap.set(parentIndex, root);			//put the current node in the parent node (index)	
					theHeap.set(index, parent );			//put the parent node in the root node	(index)
					index = parentIndex;					//assign the index to the value of the parent index
					parentIndex = ( index - 1 ) /2;			//assign the parentIndex to the value of the (root index -1 )/2
					if(index == 0)							//if the index is now the 0th element, break
						break;	
					
					root = theHeap.get(index);
					parent = theHeap.get(parentIndex);
				}
			}			
		}
		
		public void remove()
		{
			
			if(!theHeap.isEmpty() )
			{	
				theHeap.set(0, theHeap.remove(theHeap.size()-1));
				if(theHeap.size() != 0);
					sinkDown(0);
			}		
		}
		
		public void sinkDown(int index)
		{
			int largest = 0;
			int	leftChild = (2*index) + 1, rightChild = (2*index) + 2;
			
			while(index < theHeap.size()  / 2 &&  rightChild < theHeap.size() && leftChild < theHeap.size() )
			{
				if(theHeap.get(rightChild).key < theHeap.get(leftChild).key)
				{
					largest = leftChild;
				}else {
					largest = rightChild;
				}
				
				if(theHeap.get(index).key > theHeap.get(largest).key)
					break;
				
				if( theHeap.get(index).key < theHeap.get(largest).key )
				{
					swap(index, largest);
				}
				index = largest;
				leftChild = (2*index) + 1;
				
				rightChild = (2*index) + 2;
			}
		}
		
		public int findLargest(int index)
		{
			int largest = 0;
			
			if(index != theHeap.size() - 1)
			{
				int	leftChild = (2*index) + 1, rightChild = (2*index) + 2;
					
				if(theHeap.get(rightChild).key < theHeap.get(leftChild).key)
				{
					largest = leftChild;
				}else {
					largest = rightChild;
				}
			}
			return largest;
		}
		
		public void swap(int i, int c)
		{
			Data temp = theHeap.get(i);
			theHeap.set(i, theHeap.get(c) );
			theHeap.set(c, temp);
		}
		
		public void print(int index, int depth)
		{
			int i;
			int leftChild = (2*index)+1;
			int rightChild = (2*index)+2;
			
			//print the right subtree (or a dash if there is a left child and no left child
			if(rightChild <= theHeap.size() -1 )
				print(rightChild, depth+1);
			else if (leftChild <= theHeap.size() -1 )
			{
				for(i = 1; i < depth+1; i++)
					System.out.print("    ");
				System.out.println("    --");				
			}	
			
			//Print the indentation and the data from the current TreeNode:
			for(i = 1; i <=depth;i ++)
			{
				System.out.print("    ");
			}
			
			System.out.println(theHeap.get(index));
			
			//print the left subtree (or a dash i there is a right child and no left child).
			if(leftChild <= theHeap.size() -1 )
				print(leftChild, depth+1);
			else if (rightChild <= theHeap.size() -1 )
			{
				for(i = 1; i <= depth+1; i++)
					System.out.print("    ");
				System.out.print("--");
			}
		}
	}