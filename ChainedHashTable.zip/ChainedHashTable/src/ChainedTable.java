// File: ChainedTable.java from the package edu.colorado.collections
// This is an assignment for students to complete after reading Chapter 11 of
// "Data Structures and Other Objects Using Java" by Michael Main.

/******************************************************************************
* A <CODE>ChainedTable</CODE> is a chained hash table.
* The implementation isn't given here since it is an assignment in a typical
* data structures class. In general,
* programs should  use java.util.HashTable
* rather than this ChainedTable.
*
* <b>Outline of Java Source Code for this class:</b>
*   <A HREF="../../../../edu/colorado/collections/ChainedTable.java">
*   http://www.cs.colorado.edu/~main/edu/colorado/collections/ChainedTable.java
*   </A>
*
* @author Michael Main 
*   <A HREF="mailto:main@colorado.edu"> (main@colorado.edu) </A>
*
* @version Feb 10, 2016
******************************************************************************/
public class ChainedTable
{
   // Invariant of the ChainedTable class:
   //   1. An element with a given key is stored as part of the linked list at
   //      table[hash(key)].
   private ChainedHashNode[ ] table;
   private int tableSize;

     
   /**
   * Initialize an empty ChainedTable with a specified table size.
   * @param tableSize
   *   the table size for this new chained hash table
   * <b>Precondition:</b>
   *   <CODE>tableSize \&gt; 0</CODE>
   * <b>Postcondition:</b>
   *   This ChainedTable is empty and has the specified table size.
   * @exception OutOfMemoryError
   *   Indicates insufficient memory for the specified table size. 
   * @exception IllegalArgumentException
   *   Indicates that tableSize is not positive.
   **/   
   public ChainedTable(int tableSize)
   {
      if (tableSize <= 0)
	   throw new IllegalArgumentException("Table size must be positive.");
      // Allocate the table which is initially all null head references.
      table = new ChainedHashNode[tableSize];
      this.tableSize = tableSize;
   }
   
   
   /**
   * Determines whether a specified key is in this ChainedTable.
   * @param key
   *   the non-null key to look for
   * <b>Precondition:</b>
   *   <CODE>key</CODE> cannot be null.
   * @return
   *   <CODE>true</CODE> (if this ChainedTable contains an object with the specified 
   *   key); <CODE>false</CODE> otherwise. Note that <CODE>key.equals( )</CODE>
   *   is used to compare the <CODE>key</CODE> to the keys that are in the 
   *   ChainedTable.
   * @exception NullPointerException
   *   Indicates that <CODE>key</CODE> is null.
   **/
   public boolean containsKey(int key)
   {
	   int i = hash(key);
	   
	   if( table[i] != null)
	   {
		   ChainedHashNode current = table[i];
		   
		   while( true )
		   {
			   if( current.getKey() == key )
			   {
				   return true;
			   }else if( current.getNext() == null )	
			   {
					   return false;
			   }
			   else			//if next node is not null and key is not found, increment pointers
			   {
				   current = current.getNext();
			   }
		   }
		   
	   }
	   else
	   {
		   return false;
	   }
   }
   
   
   /** Retrieves an object for a specified key.
   * @param key
   *   the non-null key to look for
   * <b>Precondition:</b>
   *   <CODE>key</CODE> cannot be null.
   * @return
   *   a reference to the object with the specified <CODE>key</CODE> (if this 
   *   ChainedTable contains an such an object);  null otherwise. Note that 
   *   <CODE>key.equals( )</CODE> is used to compare the <CODE>key</CODE>
   *   to the keys that are in the ChainedTable.
   * @exception NullPointerException
   *   Indicates that <CODE>key</CODE> is null.
   **/
   public Object get(int key)
   {
	   int i = hash(key);
	   
	   if( table[i] != null)
	   {
		   ChainedHashNode current = table[i];
		   
		   while( true )
		   {
			   if( current.getKey() == key )
			   {
				  return current;
			   }else if( current.getNext() == null )	
			   {
					  return null;
			   }
			   else			//if next node is not null and key is not found, increment pointers
			   {
				   current = current.getNext();
			   }
		   }
		   
	   }
	   else
	   {
		  return null;
	   }
   }
   
   
   private int hash(int key)
   // The return value is a valid index of the ChainedTable's table. The index is
   // calculated as the remainder when the absolute value of the key's
   // hash code is divided by the size of the ChainedTable's table.
   {
      return Math.abs(key) % table.length;
   }
   
   
   /**
   * Add a new element to this ChainedTable, using the specified key.
   * @param key
   *   the non-null key to use for the new element
   * @param element
   *   the new element that's being added to this ChainedTable
   * <b>Precondition:</b>
   *   Neither <CODE>key</CODE> nor <CODE>element</CODE> is null.
   * @return
   *   If this ChainedTable already has an object with the specified <CODE>key</CODE>,
   *   then that object is replaced by <CODE>element</CODE>, and the return 
   *   value is a reference to the replaced object. Otherwise, the new 
   *   <CODE>element</CODE> is added with the specified <CODE>key</CODE>
   *   and the return value is null.
   * @exception NullPointerException
   *   Indicates that <CODE>key</CODE> or <CODE>element</CODE> is null.   
   **/
   public Object put(int key, Object element)
   {
	   int i = hash(key);
	   ChainedHashNode entry = new ChainedHashNode(key, element);
	   if( table[i] == null)
	   {
		   table[i] = entry;
	   }
	   else
	   {
		   ChainedHashNode pointer = table[i];
		   while(pointer.getNext() != null)
		   {
			   pointer = pointer.getNext();
		   }
		   pointer.setNext(entry) ;
	   }
	   
	   //System.out.println("Added " + element);
	   
	   return entry;
   }
      
   
   /**
   * Removes an object for a specified key.
   * @param key
   *   the non-null key to look for
   * <b>Precondition:</b>
   *   <CODE>key</CODE> cannot be null.
   * @return
   *   If an object was found with the specified <CODE>key</CODE>, then that
   *   object has been removed from this ChainedTable and a copy of the removed object
   *   is returned; otherwise, this ChainedTable is unchanged and the null reference
   *   is returned.  Note that 
   *   <CODE>key.equals( )</CODE> is used to compare the <CODE>key</CODE>
   *   to the keys that are in the ChainedTable.
   * @exception NullPointerException
   *   Indicates that <CODE>key</CODE> is null.
   **/
   public Object remove(int key)
   {
	   int i = hash(key);
	   
	   if( table[i] != null)
	   {
		   ChainedHashNode previous = null;
		   ChainedHashNode current = table[i];
		   
		   while( true )//losing extra people because not setting new .next's
		   {
			   if( current.getKey() == key )
			   {
				   if(previous != null)
				   {
					   previous.setNext(current.getNext());
				   }
				   else
				   {
					   table[i] = current.getNext();
				   }
				   return current;
			   }else if( current.getNext() == null )	
			   {
					   return null;
			   }
			   else			//if next node is not null and key is not found, increment pointers
			   {		
				   previous = current;
				   current = current.getNext();
			   }
		   }
		   
	   }
	   else
	   {
		   return null;
	   }
   }
   
   
   public void printTable( )
   {
	   System.out.println("\n-------------Printing Elements-------------");
	   for(int i = 0; i < table.length ; i ++ )
	   {
		   System.out.println(i);
		   if( table[i] != null)
		   {
			   ChainedHashNode pointer = table[i];
			   while(pointer != null)
			   {
				   System.out.println("\t" + pointer.getKey() + "\t" + pointer.element);
				   pointer = pointer.getNext();
			   }
		   }
	   }
	   System.out.println("-------------------------------------------\n");
   }
        
}
           